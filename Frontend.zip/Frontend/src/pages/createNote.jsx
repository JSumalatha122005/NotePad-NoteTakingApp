import React from 'react'
import Noteform from '../components/Noteform'
function createNote() {
  return (
    <Noteform />
  )
}

export default createNote